package com.boco.whl.funddemo.config;

import android.os.Environment;

/**
 * <pre>
 *  author : honglei92
 *  desc :
 *  blog :
 *  createtime : 2017/6/16 0016 9:24
 *  updatetime : 2017/6/16 0016 9:24
 * </pre>
 */
public class Constant {
    public static final String ROOT = Environment.getExternalStorageDirectory().getPath() + "/arxjavaDemo";
    public static final String FILE = ROOT + "/compressed.jpg";
    public static final String master =
            "     \n" +
                    "                   _ooOoo_" + "\n" +
                    "                  o8888888o" + "\n" +
                    "                  88\" . \"88" + "\n" +
                    "                  (| -_- |)" + "\n" +
                    "                  O\\  =  /O" + "\n" +
                    "               ____/`---'\\____" + "\n" +
                    "             .'  \\\\|     |//  `." + "\n" +
                    "            /  \\\\|||  :  |||//  \\" + "\n" +
                    "           /  _||||| -:- |||||-  \\" + "\n" +
                    "           |   | \\\\\\  -  /// |   |" + "\n" +
                    "           | \\_|  ''\\---/''  |   |" + "\n" +
                    "           \\  .-\\__  `-`  ___/-. /" + "\n" +
                    "         ___`. .'  /--.--\\  `. . __" + "\n" +
                    "      .\"\" '<  `.___\\_<|>_/___.'  >'\"\"." + "\n" +
                    "     | | :  `- \\`.;`\\ _ /`;.`/ - ` : | |" + "\n" +
                    "     \\  \\ `-.   \\_ __\\ /__ _/   .-` /  /" + "\n" +
                    "======`-.____`-.___\\_____/___.-`____.-'======" + "\n" +
                    "                   `=---='" + "\n" +
                    "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^" + "\n" +
                    "            佛祖保佑       永无BUG" + "\n" +
                    "        https://github.com/honglei92";
    public static String APP_ID = "29ca5eaac5";
    public static String TAG = "honglei92";
}
