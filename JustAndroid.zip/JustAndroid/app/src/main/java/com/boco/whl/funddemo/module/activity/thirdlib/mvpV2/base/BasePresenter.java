package com.boco.whl.funddemo.module.activity.annndroid.mvpV2.base;

/**
 * <pre>
 *  author : honglei92
 *  desc :
 *  blog :
 *  createtime : 2017/5/22 0022 10:43
 *  updatetime : 2017/5/22 0022 10:43
 * </pre>
 */
public interface BasePresenter {
    void start();
}
