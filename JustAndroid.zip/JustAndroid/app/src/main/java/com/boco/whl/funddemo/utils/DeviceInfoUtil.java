package com.boco.whl.funddemo.utils;

/**
 * Created by zhang.w.x on 2017/4/12.
 */
public class DeviceInfoUtil {

}
