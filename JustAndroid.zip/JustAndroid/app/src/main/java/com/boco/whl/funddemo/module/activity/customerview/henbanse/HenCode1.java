package com.boco.whl.funddemo.module.activity.customerview.henbanse;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.boco.whl.funddemo.R;
import com.boco.whl.funddemo.base.BaseActivity;

/**
 * author: wanghonglei@boco.com.cn
 * desc:
 * createTime: 2017/9/8 0008
 * updateTime: 2017/9/8 0008
 *
 * @author Administrator
 */

public class HenCode1 extends BaseActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_hencode1;
    }
}
