package com.boco.whl.funddemo.module.activity.annndroid.mvp.view;

/**
 * <pre>
 *  author : honglei92
 *  desc :
 *  blog :
 *  createtime : 2017/5/15 0015 10:06
 *  updatetime : 2017/5/15 0015 10:06
 * </pre>
 */
public interface IUserView {
    void setUsername(String username);

    void setPassword(String password);

}
