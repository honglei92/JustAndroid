package com.boco.whl.funddemo.module.activity.thirdlib.rxjava;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.boco.whl.funddemo.base.BaseActivity;

/**
 * @author honglei92
 * @createTime 2018/5/8 0008
 */
public class RxJavaPracticeActivity extends BaseActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected int getLayoutId() {
        return 0;
    }

}
