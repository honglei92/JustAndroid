package com.boco.whl.funddemo.module.activity.component.jetpack.paging;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.boco.whl.funddemo.R;
import com.boco.whl.funddemo.base.BaseActivity;

/**
 * @author:honglei92
 * @time:2018/8/23
 */
public class PagingTestActivity extends BaseActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_jetpack_navigation;
    }
}
