AndroidFundDemo

基础

四大组件
常用组件

机制原理

Binder
多线程
Handler
事件分发机制

三方库源码与使用

rxjava
retrofit
glide

常规技术点

性能优化

使用前沿技术

插件化
组件化

周边工具

在线部署打包
